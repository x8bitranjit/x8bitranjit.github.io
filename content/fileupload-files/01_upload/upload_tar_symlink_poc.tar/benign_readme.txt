Safe PoC -> x8bitranjit.
Tar PoC: contains a symlink entry pointing to /etc/passwd and a traversal entry.