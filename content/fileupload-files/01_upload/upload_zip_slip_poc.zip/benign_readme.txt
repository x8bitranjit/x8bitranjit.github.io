Safe PoC -> x8bitranjit.
Zip-Slip PoC. If the extractor does not sanitize entry names, the second entry writes OUTSIDE the destination directory.